package data;

import java.io.File;

import javax.swing.JButton;

import perspectives.DataSource;
import perspectives.Property;
import perspectives.PropertyManager.Options;

/**
 *
 * @author mershack
 */
public class TableData extends DataSource {

    private Table table;
    boolean valid;

    public TableData(String name) {
        super(name);

        valid = false;

        table = new Table();

        try {

            OpenFile f = new OpenFile();
            f.dialogTitle = "Open Data File";
            f.extensions = new String[3];
            f.extensions[0] = "*";
            f.extensions[1] = "txt";
            f.extensions[2] = "xml";



            Property<Boolean> p0 = new Property<Boolean>("JSON File");
            p0.setValue(false);
            addProperty(p0);


            Property<Boolean> p2 = new Property<Boolean>("Col Headers?");
            p2.setValue(true);
            this.addProperty(p2);

            Property<Options> p3 = new Property<Options>("Delimiter");
            Options o = new Options();
            o.options = new String[3];
            o.options[0] = "TAB";
            o.options[1] = "SPACE";
            o.options[2] = "COMMA";
            o.selectedIndex = 0;
            p3.setValue(o);
            this.addProperty(p3);

            Property<OpenFile> p1 = new Property<OpenFile>("Tabular File");
            p1.setValue(f);
            addProperty(p1);




        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public <T> void propertyUpdated(Property p, T newvalue) {
        boolean js = (Boolean) getProperty("JSON File").getValue();
        
        if (js) {
            //se;
            this.removeProperty("Col Headers?");
            this.removeProperty("Delimiter");

        }

        if (p.getName() == "Tabular File") {

           if(!js){
                boolean ch = (Boolean) getProperty("Col Headers?").getValue();


              //hide the others if it is a json file

             int delim = ((Options) (getProperty("Delimiter").getValue())).selectedIndex;
             OpenFile f = ((OpenFile) newvalue);
             String d = "\t";   //default selection
             if (delim == 1) {
                d = " ";
              } else if (delim == 2) {
                d = ",";
              }

              table.fromFile(f.path, d, ch);  //Function to Get the Data from File
           }
           else{   //get the data from a JSON format
               
           }
            
           

            
            
            
            
            
            //Determine the properties of the file such as number of rows and columns and print them on the screen
            if (table.getColCount() != 0) {
                this.setLoaded(true);

                this.removeProperty("Tabular File");
                this.removeProperty("Delimiter");
                this.removeProperty("Col Headers?");
                this.removeProperty("JSON File");

                try {
                    Property<Integer> p1 = new Property<Integer>("# Columns");
                    p1.setValue(table.getColCount());
                    p1.setReadOnly(true);
                    this.addProperty(p1);

                    Property<Integer> p2 = new Property<Integer>("# Rows");
                    p2.setValue(table.getRowCount());
                    p2.setReadOnly(true);
                    this.addProperty(p2);

                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
        }

        //}
    }

    /* Method to get the table */
    public Table getTable() {
        return table;
    }

    /* method to set that the table is valid */
    public boolean isValid() {
        return valid;
    }
}
