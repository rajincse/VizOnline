/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStream;
import java.util.Vector;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Arrays;

//import org.json.JSONArray;
//import org.json.JSONException;


/**
 *
 * @author mershack
 */

public class Table {

    ArrayList<String> columnHeaders = null;
    String[] rowHeaders;
    
    ArrayList<TableColumn> data;
  
    int rowCount;
 
    
    public enum TableElementType { Integer, Double, String};
    
    public Table()
    {
    	rowCount = 0;
    	
    	data = new ArrayList<TableColumn>();
    }
    
    public void addColumn(TableColumn c)
    {
    	if (data.size() == 0)
    		rowCount = c.getCount();
    	else if (rowCount != c.getCount())
    		System.exit(0);
    	
    	data.add(c);   	
    }
    
    public void addColumn(TableColumn c, String header)
    {
    	if (data.size() == 0)
    		rowCount = c.getCount();
    	else if (rowCount != c.getCount())
    		System.exit(0);
    	
    	data.add(c);  
    	
    	if (columnHeaders == null)
    	{
    		columnHeaders = new ArrayList<String>();
    		for (int i=0; i<data.size()-1; i++)
    			columnHeaders.add("");
    	}
    	columnHeaders.add(header);    		
    }  
    
    public TableColumn getColumn(int index)
    {
    	if (index < 0 || index >= data.size())
    		System.exit(0);
    	
    	return data.get(index);
    }
    
    public void removeColumn(int index)
    {
    	if (index < 0 || index >= data.size())
    		System.exit(0);
    }
    
    public void insertRow(int index, TableRow r)
    {
    	//first check if types match
    	for (int i=0; i<r.getCount(); i++)
    		if ()
    }
    

    int [][] XY_coords;
    int colMax[]; // maximum values for all the columns... for strings, it will be the count of distinct elements
    int colMin[];  //minimum values for all the columns ... for strings, it will be 0;

    
    



    /**
     * This function will set the max and minimum values for all the columns
     */
    public void setMaxMin() {
        //For String items, that lowest value will havve to be 0 whiles their highest value has to be  the count of the items
        //for the others we use their minimum and max values
        int val;
        //Initialize the colMax and colMin  variables
        String[] strvals;
        
        colMax = new int[colLength];
        colMin = new int[colLength];
        for (int i = 0; i < colLength; i++) {

            if (datafields[i].getIsNumeric()) //if numeric, then find the minimum and maximum values
            {
                colMax[i] = (int) Math.round(Float.parseFloat(data[0][i]));
                colMin[i] = (int) Math.round(Float.parseFloat(data[0][i]));
                
                /*Get the minimum and maximum values in the  numeric fields */
                for (int j = 0; j < rowLength; j++) {
                  val = (int) Math.round(Float.parseFloat(data[j][i]));
                   if (val > colMax[i]) {
                    colMax[i] = val;
                   } else if (val < colMin[i]) {
                    colMin[i] = val;
                }
              }
            }else{
               
                strvals = DistinctColVal(i);
                colMax[i] = strvals.length; 
                colMin[i] = 0;
                
            }
            
             //System.out.println("The max value for Col "+  i + " is " + colMax[i]);
             //System.out.println("The min value for Col "+  i + " is " + colMin[i]);
  
        }
        
        
       

    }
    
    
    public void setXYCoords(){
        XY_coords = new int[rowLength][colLength];
        String[] distinct;
        for (int i = 0; i < colLength; i++) {

            if (datafields[i].getIsNumeric()) //if numeric, then convert the values to float
            {                         
                /*all the values in that column will be converted to float */
                for (int j = 0; j < rowLength; j++) {
                  XY_coords[j][i] = (int) Math.round(Float.parseFloat(data[j][i]));
              }
            }else{
                
               distinct = DistinctColVal(i);
               //set the index of the distinct item in the array to the value of the distinct value
               for(int k = 0; k<distinct.length; k++)
               {
                   for(int m=0; m<rowLength; m++){
                       if(data[m][i].equalsIgnoreCase(distinct[k])){
                           XY_coords[m][i] = k+1;   //the index of the XY coordinate the distinct values will be from 1 to length of distinct
                       }
                   }
               }
                
            }
  
        }
        
       // printXYcoords();
        
    }
    
    
     public String[][] getData(){
        return data;
    }
    
    
    
    public void printXYcoords(){
          System.out.println("The XY-coords are: ");
        for (int i=0; i<rowLength; i++){
            for(int j=0; j<colLength; j++){
                System.out.print(" " + XY_coords[i][j]);
            }
            System.out.println();
        }
    }
    
    public void printMaxs(){
        
         System.out.println("The Maximums are: ");
        for(int j=0; j<colLength; j++){
                System.out.print(" " + colMax[j]);
            }
            
    }
    
    
    
   public int[] getColMax(){
       return colMax;
   }
   
   public int[] getColMin(){
       return colMin;
   }
    

    public String[] DistinctColVal(int columnid) {

        String[] distinctColVals;

        String columnList[] = new String[rowLength];

        for (int i = 0; i < rowLength; i++) {
            columnList[i] = data[i][columnid];
        }


        //convert the Strings to a Set array, which can subsequently have the unique items.
        Set<String> strset = new HashSet<String>(Arrays.asList(columnList));


        distinctColVals =  strset.toArray(new String[0]);

      //  System.out.println("The size of the distinct items is "+ distinctColVals.length);
        return distinctColVals;
    }

    public int CountDistinctColVals(int columnid) {
        int count = 0;
        //Create a list of all the strings in that column

        String columnList[] = new String[rowLength];

        for (int i = 0; i < rowLength; i++) {
            columnList[i] = data[i][columnid];
        }


        //convert the Strings to a Set array, which can subsequently have the unique items.
        Set<String> strset = new HashSet<String>(Arrays.asList(columnList));


        count = strset.size();
        return count;
    }

    /**
     * create a datafields array which will contain attributes of the fields
     *
     */
    private void createDatafileds(int length) {
        datafields = new TableColumns[length];
        for (int i = 0; i < datafields.length; i++) {
            datafields[i] = new TableColumns(columnHeaders[i]);
        }
    }
    
    public int[][] getXYCoords(){
        return XY_coords;
    }

    public void fromFile(String filename, String delim, boolean colH) {
        try {
            BufferedReader in = new BufferedReader(new FileReader(filename));

            String str;
            ArrayList<String> lines = new ArrayList<String>();
            while ((str = in.readLine()) != null) {
                lines.add(str);
            }

            if (colH && lines.size() != 0) //if there are column headers...Column headers are needed
            {
                String[] split = lines.get(0).split(delim);


                columnHeaders = new String[split.length];
               

                for (int i = 0; i < split.length; i++) {
                    columnHeaders[i] = split[i];
                }

                lines.remove(0);   //remove the headers



                colLength = split.length;
                rowLength = lines.size();

                /**
                 * create the datafields
                 */
                createDatafields(colLength);

                data = new String[rowLength][colLength];

               
             
                   split = lines.get(0).split(delim);   //get the first row of items of the line
                   
                /* This check the data of the first row and determines the datatype of each column */
                   
                for (int i = 0; i < colLength; i++) {
                    if (isNumeric(split[i].trim())) {
                        datafields[i].setIsNumeric(true);
                        if (isInteger(split[i].trim())) {
                            datafields[i].setType("Integer");
                            datafields[i].setCategory(TableColumns.INTERVAL);
                        } else {
                            datafields[i].setType("Double");
                            datafields[i].setCategory(TableColumns.RATIO);
                        }

                    } else {
                        //System.out.println("collength : " + colLength + " SplitLength: " + split.length);
                        datafields[i].setIsNumeric(false);
                        datafields[i].setType("String");
                        datafields[i].setCategory(TableColumns.NOMINAL);
                    }

                }
               
                /**
                 * * Get the data and place them in the array*
                 */
                String s="";    //to be used to get the different splits
                for (int i = 0; i < rowLength; i++) {
                    split = lines.get(i).split(delim);

                    for (int j = 0; j < colLength; j++) {
                        
                        //normalize all missing string data to 'missing' and all missing numeric numbers to 0.
                       
                        if(j < split.length) //to avoid arrayout of index for columns that have not entries
                        {
                                s = split[j];
                        }else{
                            s = "";
                        }
                            
                        
                        if(datafields[j].getIsNumeric() && s.equalsIgnoreCase(""))
                        {
                                data[i][j] = DEFAULTNUMERIC +"";
                        }
                        else if (s.equalsIgnoreCase("")){
                            data[i][j] = DEFAULTSTRING;
                        }
                        else{
                                data[i][j] = s;
                        }
                       // System.out.print(data[i][j]+ "  ");
                        
                        s = " ";
                       
                    }
                   // System.out.println();
                    
                }

                in.close();
                
                
                
            }
            
            
        setMaxMin();
        setXYCoords();

        } catch (Exception e) {
            e.printStackTrace();
        }


        
        
        

    }
    
    
    
    public void fromJSON(String filename){
       
               
              
    }

    /**
     * checking if number is numeric numeric numbers are integers or float
     * for now I will take only floats as numerics 
     */
    public boolean isNumeric(String str) {

        if(str.matches("\\d+(\\.\\d+)?"))
             return true;
    
        return false;
 
    }

    /**
     * Checking if number is an integer
     *
     * @param str
     * @return
     */
    public boolean isInteger(String str) {
        return str.matches("\\d+");
    }

    /**
     * Checking if number is double
     */
    public boolean isDouble(String str) {
        return str.matches("\\d+\\.\\d+");
    }

    public int getColCount() {
        return colLength;
    }

    public int getRowCount() {
        return rowLength;
    }
    
    //public String[] getRow(int r)
    //{
    	
   // }
    
  //  public String[] getColumn(int c)
   // {
    	
  //  }
    
    /*public ColumnType getColumnType(int c)
    {
    	boolean foundDouble = false;    	
    	
    	String[] col = getColumn(c);
    	
    	for (int i=0; i<col.length; i++)
    		if (!isNumeric(col[i]))
    			return ColumnType.Categorical;
    		else if (!foundDouble && isDouble(col[i]))
    			foundDouble = true;
    	
    	if (foundDouble)
    		return ColumnType.Double;
    	else return ColumnType.Integer;
    }*/
    
    

    /*  public void normalizeTable() {
     for (int col = 0; col < data[0].length; col++) {
     if (datatypes[col].equalsIgnoreCase("Number")) {
     /* int step = data.getColumnRange(col);
     for (var row = 0; row < data.getNumberOfRows(); row++) {
     data.setCell(row, col, data.getValue(row, col) - (step.min));
     }
     }
     }
     }*/
}
