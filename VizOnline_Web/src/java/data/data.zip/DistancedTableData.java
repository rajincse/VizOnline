package data;

public class DistancedTableData extends TableData implements DistancedPoints{

	public DistancedTableData(String name) {
		super(name);
	}

	@Override
	public int getNumberOfPoints() {
		return getTable().getRowCount();
	}

	@Override
	public float getDistance(int index1, int index2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getPointId(int index) {
		// TODO Auto-generated method stub
		return null;
	}
	
	private float computeDistance(int i1, int i2)
	{
		String[] v1 = getTable().getData()[i1];
		String[] v2 = getTable().getData()[i2];
		
		for (int i=0; i<v1.length; i++)
		{
			getTable().
		}
		
		
	}

}
