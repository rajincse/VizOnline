package data;

import data.Table.TableElementType;

public class TableRow 
{
	private TableElementType[] types;	
	Object[] values;
		
	public TableRow(int count, TableElementType[] types)
	{
		this.types = types;
		
		if (count != types.length)
			System.exit(0);
		
		values = new Object[count];
		
		for (int i=0; i<count; i++)
			if (types[i] == TableElementType.Double)
				values[i] = new Double(0);
			else if (types[i] == TableElementType.Integer)
				values[i] = new Integer(0);
			else
				values[i] = new String();
	}
	
	public int getCount()
	{
		return types.length;
	}
	
	public TableElementType getTypeAt(int index)
	{
		return types[index];
	}
	
	public double getDoubleValue(int index)
	{
		if (types[index] != TableElementType.Double)
			System.exit(0);
		
		return ((Double)values[index]).doubleValue();
	}
	
	public void setDoubleValue(int index, double v)
	{
		if (types[index] != TableElementType.Double)
			System.exit(0);
		
		values[index] = new Double(v);
	}
	
	public String getStringValue(int index)
	{
		if (types[index] != TableElementType.String)
			System.exit(0);
		
		return ((String)values[index]);		
	}
	
	public void setStringValue(int index, String v)
	{
		if (types[index] != TableElementType.String)
			System.exit(0);
		
		values[index] = v;
	}
	
	
	public int getIntValue(int index)
	{
		if (types[index] != TableElementType.Integer)
			System.exit(0);
		
		return ((Integer)values[index]).intValue();		
	}
	
	public void setIntValue(int index, int v)
	{
		if (types[index] != TableElementType.Integer)
			System.exit(0);
		
		values[index] = new Integer(v);
	}	
	
	public void fromString(String s, String delim)
	{
		String[] split = s.split(delim);
		
		if (split.length != types.length)
			System.exit(0);
		
		for (int i=0; i<split.length; i++)
			if (types[i] == TableElementType.Double)
				values[i] = new Double(Double.parseDouble(split[i]));
			else if (types[i] == TableElementType.Integer)
				values[i] = new Integer(Integer.parseInt(split[i]));
			else if (types[i] == TableElementType.String)
				values[i] = split[i];
	}
	
}
