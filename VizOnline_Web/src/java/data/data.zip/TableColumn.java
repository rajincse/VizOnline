/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import data.Table.TableElementType;

/**
 *
 * @author mershack
 */


public class TableColumn {	
	
	TableElementType type;
	int count;
	
	int[] intValues = null;
	double[] doubleValues = null;
	String[] stringValues = null;
	
	public TableColumn(int count, TableElementType t)
	{
		type = t;
		this.count = count;
		
		if (type == TableElementType.String)
			stringValues = new String[count];
		if (type == TableElementType.Double)
			doubleValues = new double[count];
		if (type == TableElementType.Integer)
			intValues = new int[count];
	}
	
	public int getCount()
	{
		return count;
	}
	
	public void setValue(int index, String v)
	{
		if (type == TableElementType.String && index >= 0 && index < stringValues.length)
			stringValues[index] = v;
		if (type == TableElementType.Integer && index >= 0 && index < intValues.length)
			intValues[index] = Integer.parseInt(v);
		if (type == TableElementType.Double && index >= 0 && index < doubleValues.length)
			doubleValues[index] = Double.parseDouble(v);			
	}
	
	public void setStringValue(int index, String v)
	{
		if (type != TableElementType.String || index < 0 || index >= stringValues.length)
			System.exit(0);
		
		stringValues[index] = v;		
	}
	
	public void setIntValue(int index, int v)
	{
		if (type != TableElementType.Integer || index < 0 || index >= intValues.length)
			System.exit(0);
		
		intValues[index] = v;		
	}
	
	public void setStringValue(int index, double v)
	{
		if (type != TableElementType.Double || index < 0 || index >= doubleValues.length)
			System.exit(0);
		
		doubleValues[index] = v;		
	}
}
